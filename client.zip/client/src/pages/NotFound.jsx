function NotFound()  {
    return <h1>PAGINA NO ENCONTRADA</h1>
}

export default NotFound